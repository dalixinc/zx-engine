ATLANTIS — ZX SPECTRUM ATTRIBUTE-CONSTRAINED ARTWORK

Source: original Atlantis concept artwork.
192x128 city: 3072 bytes bitmap + 384 bytes attributes = 3456 bytes raw.
256x192 screen: 6144 bytes bitmap + 768 bytes attributes = 6912 bytes .scr.

Colour conversion: each 8x8 cell uses one INK, one PAPER, and shared BRIGHT; no FLASH.
Preview PNGs show the converted colours; 3x PNGs use nearest-neighbour enlargement.
Bitmap BIN: top-to-bottom row-major, 8 pixels per byte, left pixel = bit 7.
Attribute BIN: top-to-bottom row-major, 24 bytes per row for city, 32 for screen.
Attribute format: FLASH(7), BRIGHT(6), PAPER(5:3), INK(2:0).
ATL format: ATLS magic, uint16 LE width, uint16 LE height, uint32 LE bitmap length, uint32 LE attribute length, then bitmap bytes and attribute bytes.
Full-screen .scr: standard Spectrum interleaved bitmap memory order + 768 attribute bytes.
Important: the 192x128 image is an asset, NOT a standalone .scr. Pixel-by-pixel scrolling will need attribute-aware rendering or colour strategy.
ZX0 compression has NOT been applied; compression estimate below is zlib only, NOT ZX0.
zlib (illustrative) city bitmap+attrs: 1896 bytes; screen: 3127 bytes.
