# Verifies every number in ZX-Screen-Handling.md
def disp(x,y):
    T,L,S,C = y>>6,(y>>3)&7,y&7,x>>3
    return 0x4000 | T<<11 | S<<8 | L<<5 | C
def disp_dec(x,y):  # decimal formula used in the guide
    return 16384 + 2048*(y//64) + 256*(y%8) + 32*((y//8)%8) + x//8
def attr_rc(r,c): return 0x5800 + r*32 + c
def disp_rc(r,c): return 0x4000 | (r>>3)<<11 | (r&7)<<5 | c   # pixel line 0 of a char cell
def to_attr_z80(hl):
    h,l=hl>>8,hl&0xFF
    a=h
    for _ in range(3): a=((a>>1)|((a&1)<<7))&0xFF   # RRCA
    a&=3; a|=0x58
    return a<<8|l
def next_line(hl):
    """Simulate the guide's routine; returns (new hl, T-states incl. RET)."""
    h,l=hl>>8,hl&0xFF; t=0
    h=(h+1)&0xFF; t+=4            # INC H
    a=h; t+=4                     # LD A,H
    a&=7; t+=7                    # AND 7
    if a!=0: return (h<<8|l, t+11)   # RET NZ taken
    t+=5
    a=l; t+=4                     # LD A,L
    s=a+32; carry=s>0xFF; a=s&0xFF; t+=7   # ADD A,32
    l=a; t+=4                     # LD L,A
    if carry: return (h<<8|l, t+11)        # RET C taken
    t+=5
    a=h; t+=4; a=(a-8)&0xFF; t+=7; h=a; t+=4  # LD A,H / SUB 8 / LD H,A
    return (h<<8|l, t+10)          # RET

# 1. memory map
assert 0x4000==16384 and 0x57FF==22527 and 0x57FF-0x4000+1==6144
assert 0x5800==22528 and 0x5AFF==23295 and 0x5AFF-0x5800+1==768
assert 6144+768==6912 and 256*192//8==6144 and 32*24==768
# every pixel byte maps to a unique address covering exactly the display file
addrs={disp(x,y) for y in range(192) for x in range(0,256,8)}
assert addrs==set(range(0x4000,0x5800))
for y in range(192):
    for x in range(256): assert disp(x,y)==disp_dec(x,y)
# fill order: address order = third, then pixel line, then char row
order=sorted(((disp(x,y),y) for y in range(192) for x in range(0,256,8)))
ys=[y for i,(a,y) in enumerate(order) if i%32==0]
assert ys[:9]==[0,8,16,24,32,40,48,56,1] and ys[64]==64
# figure-1 addresses
assert [disp(0,y) for y in range(8)]==[0x4000+0x100*i for i in range(8)]
assert disp(0,8)==0x4020 and disp(0,16)==0x4040 and disp(0,56)==0x40E0 and disp(0,63)==0x47E0
assert disp(0,64)==0x4800 and disp(0,128)==0x5000
# 3. attribute address from bits
for r in range(24):
    for c in range(32):
        a=attr_rc(r,c); assert a == (0x5800 | (r>>3)<<8 | (r&7)<<5 | c)
assert attr_rc(0,31)==0x581F and attr_rc(1,0)==0x5820 and attr_rc(23,31)==0x5AFF
# 5. worked examples
ex={(0,0):None,(100,50):None,(255,191):None,(128,77):None}
for (x,y) in ex:
    a=disp(x,y); print(f"pixel ({x},{y}): T={y>>6} L={(y>>3)&7} S={y&7} C={x>>3} bit={7-(x&7)} -> ${a:04X} = {a}")
assert disp(0,0)==0x4000 and disp(100,50)==0x42CC and disp(255,191)==0x57FF and disp(128,77)==0x4D30
# INC H within a char
assert disp(40,50)+0x100==disp(40,51)
# char-row crossing (40,15)->(40,16)
a15=disp(40,15); a16=disp(40,16); print(f"(40,15) ${a15:04X}  (40,16) ${a16:04X}  INC H alone ${a15+0x100:04X}")
assert a15==0x4725 and a16==0x4045 and a15+0x100==0x4825
# third crossing 63->64
assert disp(0,63)==0x47E0 and disp(0,64)==0x4800
# row 10 col 5
assert disp_rc(10,5)==0x4845==18501 and attr_rc(10,5)==0x5945==22853 and 22528+10*32+5==22853
assert 16384+2048*1+32*2+5==18501
# z80 attr conversion: every display byte
for y in range(192):
    for c in range(32):
        assert to_attr_z80(disp(c*8,y))==attr_rc(y//8,c)
assert to_attr_z80(0x4845)==0x5945 and to_attr_z80(0x42CC)==0x58CC and to_attr_z80(0x4D30)==0x5930
# next-line routine for every line
times={}
for y in range(191):
    for c in range(32):
        n,t=next_line(disp(c*8,y)); assert n==disp(c*8,y+1),(y,c)
        kind='inside' if (y+1)%8 else ('third' if (y+1)%64==0 else 'row')
        times.setdefault(kind,set()).add(t)
print("next_line T-states:",times)
assert times=={'inside':{26},'row':{65},'third':{46}}
print("y=191 ->", hex(next_line(disp(0,191))[0]))
# attribute byte examples
def attrb(f,b,p,i): return f<<7|b<<6|p<<3|i
assert attrb(0,0,7,0)==56==0x38 and attrb(0,1,1,7)==0x4F==79 and attrb(1,0,2,6)==0x96==150
assert attrb(0,0,1,6)==0x0E==14
# row table
assert 192*2==384
# avg cost of next_line over 191 transitions (per column irrelevant)
cnt={'inside':168,'row':21,'third':2}
assert sum(cnt.values())==191
print("avg T:", (168*26+21*65+2*46)/191)
print("ALL CHECKS PASSED")
# row-table lookup: row start low byte has column bits clear, so OR C gives the column
for y in range(192): assert disp(0,y)&0x1F==0
for y in range(192):
    for c in range(32): assert (disp(0,y) | c) == disp(c*8,y)
assert 4+7+11+10+11+7+6+7+4+4==71
print("ROW TABLE CHECKS PASSED")
from collections import Counter
k=Counter('inside' if (y+1)%8 else ('third' if (y+1)%64==0 else 'row') for y in range(191))
assert k==Counter(inside=168,row=21,third=2)
# char row step from line 0: L+32, if carry H+8
for r in range(23):
    for c in range(32):
        a=disp_rc(r,c); h,l=a>>8,a&0xFF; l+=32
        if l>0xFF: l&=0xFF; h+=8
        assert (h<<8|l)==disp_rc(r+1,c)
assert 34==4+4*3+7+7+4 and 26==4+4+7+11 and 0x22AA==8874 and 0x5800+0x145==0x5945 and 10*32+5==325==0x145
print("EXTRA CHECKS PASSED")
